#ifndef LINIT_H
#define LINIT_H

int luaopen_init(lua_State *L);

#endif
