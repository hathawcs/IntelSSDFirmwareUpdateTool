#ifndef LPOSIX_H
#define LPOSIX_H

int luaopen_posix (lua_State *L);
int luaopen_rpm_os (lua_State *L);

#endif
