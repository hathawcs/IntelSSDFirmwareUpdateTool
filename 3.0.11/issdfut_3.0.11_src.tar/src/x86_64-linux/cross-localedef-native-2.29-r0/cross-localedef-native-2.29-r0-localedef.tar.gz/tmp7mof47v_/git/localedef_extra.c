const char *program_name = "localedef";
const char *program_invocation_name = "localedef";
const char *program_invocation_short_name = "localedef";
