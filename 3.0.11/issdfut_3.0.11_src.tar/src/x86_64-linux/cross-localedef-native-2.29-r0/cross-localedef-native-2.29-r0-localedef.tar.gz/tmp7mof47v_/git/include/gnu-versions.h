#include_next <gnu-versions.h>
#undef _GNU_GETOPT_INTERFACE_VERSION
#define _GNU_GETOPT_INTERFACE_VERSION 0
