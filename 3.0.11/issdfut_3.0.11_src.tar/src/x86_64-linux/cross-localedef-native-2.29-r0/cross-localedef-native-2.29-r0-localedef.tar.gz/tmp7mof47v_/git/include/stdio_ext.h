#ifdef HAVE_STDIO_EXT_H
#include_next <stdio_ext.h>
#else
#include <stdio.h>
#endif
