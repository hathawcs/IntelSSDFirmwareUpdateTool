/* Used for error checking.  To support hosts without regcomp, this 1
   could come from a configure check.  */
#define __OPTION_POSIX_REGEXP 1
