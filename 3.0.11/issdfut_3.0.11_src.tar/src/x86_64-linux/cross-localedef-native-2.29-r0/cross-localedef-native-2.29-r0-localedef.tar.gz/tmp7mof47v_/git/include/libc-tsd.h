#ifndef __libc_tsd_define
#define __libc_tsd_define(A,B,C)
#endif
