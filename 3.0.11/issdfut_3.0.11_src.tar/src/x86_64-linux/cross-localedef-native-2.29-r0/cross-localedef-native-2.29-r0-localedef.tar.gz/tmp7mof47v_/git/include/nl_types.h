#ifdef HAVE_NL_TYPES_H
#include_next <nl_types.h>
#else
#ifndef NL_TYPES_H
#define NL_TYPES_H
typedef int nl_item;
#endif
#endif
