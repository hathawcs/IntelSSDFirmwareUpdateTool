import os

opkdir = "/tmp/opk"
offline_root = "/tmp/opkg"
opkgcl = os.path.realpath("../src/opkg")
