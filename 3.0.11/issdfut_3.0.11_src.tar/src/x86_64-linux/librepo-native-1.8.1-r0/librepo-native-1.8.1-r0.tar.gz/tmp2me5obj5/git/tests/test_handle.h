#ifndef LR_TEST_HANDLE_H
#define LR_TEST_HANDLE_H

#include <check.h>

Suite *handle_suite(void);

#endif
