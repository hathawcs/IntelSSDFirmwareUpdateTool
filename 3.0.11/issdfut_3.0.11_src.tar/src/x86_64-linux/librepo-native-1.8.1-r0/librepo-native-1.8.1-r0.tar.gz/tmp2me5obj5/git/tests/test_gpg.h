#ifndef LR_TEST_GPG_H
#define LR_TEST_GPG_H

#include <check.h>

Suite *gpg_suite(void);

#endif
