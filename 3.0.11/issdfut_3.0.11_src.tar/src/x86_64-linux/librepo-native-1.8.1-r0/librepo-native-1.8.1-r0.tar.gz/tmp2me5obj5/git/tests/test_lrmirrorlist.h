#ifndef LR_TEST_LRMIRRORLIST_H
#define LR_TEST_LRMIRRORLIST_H

#include <check.h>

Suite *lrmirrorlist_suite(void);

#endif
