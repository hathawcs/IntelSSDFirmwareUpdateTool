/* 
 * Copyright (c) 2010 Wind River Systems; see
 * guts/COPYRIGHT for information.
 *
 * static int
 * wrap_acct(const char *path) {
 *	int rc = -1;
 */

	rc = real_acct(path);

/*	return rc;
 * }
 */
