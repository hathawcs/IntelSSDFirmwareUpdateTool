int bar = 26;
int baz = 28;

int f1 (void)
{
  return 1;
}

int f2 (void)
{
  return 2;
}
