#include "orderlib.h"
#include "orderlib1.h"

int orderlib1(void)
{
   int rc = 0;
   rc += value();
   rc += value1();
   return rc;
}
