int q1 (void)
{
  return q2 () + 1;
}

int q2 (void)
{
  return 77;
}
