int bar = 36;
int baz = 38;

int f1 (void)
{
  return 11;
}

int f2 (void)
{
  return 12;
}
