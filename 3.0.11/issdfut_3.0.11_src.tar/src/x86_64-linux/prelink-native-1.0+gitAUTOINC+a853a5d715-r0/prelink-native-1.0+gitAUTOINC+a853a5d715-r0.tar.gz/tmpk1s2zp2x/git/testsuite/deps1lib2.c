#include "reloc1.h"

int f1 (void)
{
  return 11;
}

int f8 (void)
{
  return f9 () - 1;
}
