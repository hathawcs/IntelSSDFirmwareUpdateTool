int var = 32;
extern int var2;

int var2m1 (void)
{
  return var2 - 10;
}
