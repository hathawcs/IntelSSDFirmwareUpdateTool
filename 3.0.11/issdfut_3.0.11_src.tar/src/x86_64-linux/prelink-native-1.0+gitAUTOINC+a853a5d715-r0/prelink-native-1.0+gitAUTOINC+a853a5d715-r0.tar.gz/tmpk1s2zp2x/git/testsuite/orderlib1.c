#include "orderlib.h"

int value1(void)
{
   return 10;
}
